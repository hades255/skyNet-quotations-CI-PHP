<div class="white-area-content">

<div class="db-header clearfix">
    <div class="page-header-title"> <span class="glyphicon glyphicon-user"></span> Admin Page</div>
    <div class="db-header-extra">
</div>
</div>

<ol class="breadcrumb">
  <li><a href="<?php echo site_url() ?>">Home</a></li>
  <li class="active">Admin Page</li>
</ol>

<p>This is an example of a page in which only users with Admin status can access. You can set a User's status in the Admin Panel area.</p>
<hr>
</div>