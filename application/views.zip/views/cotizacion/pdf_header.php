<style type="text/css">
<!--

-->
</style>
<table width="100%" border="1" cellpadding="4" cellspacing="0">
 
  <tr height="21">
    <td colspan="2" rowspan="4">[LOGO]</td>
    <td width="642" height="21" colspan="8"><div align="right" class="Estilo23">CAPSA PANAMA, S.A.</div></td>
  </tr>
  <tr height="17">
    <td width="642" height="17" colspan="8"><div align="right">Panama Viejo Bussiness    Center, Ofibodega G15</div></td>
  </tr>
  <tr height="16">
    <td width="642" height="16" colspan="8"><div align="right">Panam&aacute;, Rep. Panam&aacute;.    Tel: 394-7115</div></td>
  </tr>
  <tr height="28">
    <td width="642" height="28" colspan="8"><div align="right">RUC: 2045641-1-747141    D.V 53&nbsp;</div></td>
  </tr>
</table>
